<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

try {
    // Buscar configuração específica ou todas
    $chave = $_GET['chave'] ?? null;
    
    if ($chave) {
        // Buscar configuração específica
        $config = $db->select('configuracoes', 'chave,valor,tipo,descricao', ['chave' => $chave]);
        
        if (!$config || count($config) === 0) {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'message' => 'Configuração não encontrada'
            ]);
            exit;
        }
        
        $item = $config[0];
        
        // Converter valor baseado no tipo
        $valorConvertido = convertValue($item['valor'], $item['tipo']);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'chave' => $item['chave'],
                'valor' => $valorConvertido,
                'tipo' => $item['tipo'],
                'descricao' => $item['descricao']
            ]
        ]);
        
    } else {
        // Buscar todas as configurações
        $configs = $db->select('configuracoes', 'chave,valor,tipo,descricao');
        
        if (!$configs) {
            throw new Exception('Erro ao buscar configurações');
        }
        
        // Organizar por categoria/grupo
        $configsOrganizadas = [
            'geral' => [],
            'votacao' => [],
            'visual' => [],
            'email' => [],
            'seguranca' => []
        ];
        
        foreach ($configs as $config) {
            $chave = $config['chave'];
            $valorConvertido = convertValue($config['valor'], $config['tipo']);
            
            $item = [
                'chave' => $chave,
                'valor' => $valorConvertido,
                'tipo' => $config['tipo'],
                'descricao' => $config['descricao']
            ];
            
            // Categorizar baseado no prefixo da chave
            if (strpos($chave, 'site_') === 0 || strpos($chave, 'data_gala') === 0) {
                $configsOrganizadas['geral'][] = $item;
            } elseif (strpos($chave, 'votacao_') === 0 || strpos($chave, 'data_') === 0) {
                $configsOrganizadas['votacao'][] = $item;
            } elseif (strpos($chave, 'cor_') === 0 || strpos($chave, 'tema_') === 0 || strpos($chave, 'mostrar_') === 0) {
                $configsOrganizadas['visual'][] = $item;
            } elseif (strpos($chave, 'smtp_') === 0 || strpos($chave, 'email_') === 0) {
                $configsOrganizadas['email'][] = $item;
            } else {
                $configsOrganizadas['seguranca'][] = $item;
            }
        }
        
        echo json_encode([
            'success' => true,
            'data' => $configsOrganizadas,
            'total' => count($configs)
        ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar configurações: ' . $e->getMessage()
    ]);
}

/**
 * Converte o valor baseado no tipo
 */
function convertValue($value, $type) {
    switch ($type) {
        case 'numero':
            return is_numeric($value) ? (int)$value : 0;
        
        case 'booleano':
            return $value === 'true' || $value === '1' || $value === 1;
        
        case 'json':
            return json_decode($value, true) ?? $value;
        
        case 'data':
            return $value;
        
        default:
            return $value;
    }
}