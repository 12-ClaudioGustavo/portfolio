<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

// Verificar autenticação
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Pode receber uma única configuração ou múltiplas
    $configuracoes = isset($data['configuracoes']) ? $data['configuracoes'] : [$data];
    
    $atualizadas = [];
    $erros = [];
    
    try {
        foreach ($configuracoes as $config) {
            $chave = $config['chave'] ?? null;
            $valor = $config['valor'] ?? null;
            
            if (!$chave) {
                $erros[] = 'Chave não especificada em uma das configurações';
                continue;
            }
            
            // Verificar se configuração existe
            $configExistente = $db->select('configuracoes', 'id,tipo', ['chave' => $chave]);
            
            if (!$configExistente || count($configExistente) === 0) {
                // Criar nova configuração
                $tipo = $config['tipo'] ?? 'texto';
                $descricao = $config['descricao'] ?? '';
                
                $resultado = $db->insert('configuracoes', [
                    'chave' => $chave,
                    'valor' => prepareValue($valor, $tipo),
                    'tipo' => $tipo,
                    'descricao' => $descricao
                ]);
                
                if ($resultado) {
                    $atualizadas[] = $chave;
                } else {
                    $erros[] = "Erro ao criar configuração: {$chave}";
                }
                
            } else {
                // Atualizar configuração existente
                $tipo = $configExistente[0]['tipo'];
                
                $resultado = $db->update('configuracoes', [
                    'valor' => prepareValue($valor, $tipo),
                    'updated_at' => date('Y-m-d H:i:s')
                ], [
                    'chave' => $chave
                ]);
                
                if ($resultado !== false) {
                    $atualizadas[] = $chave;
                } else {
                    $erros[] = "Erro ao atualizar configuração: {$chave}";
                }
            }
        }
        
        // Registrar na auditoria
        if (count($atualizadas) > 0) {
            $db->insert('historico_acoes', [
                'acao' => 'atualizar_configuracoes',
                'tabela' => 'configuracoes',
                'detalhes' => json_encode([
                    'atualizadas' => $atualizadas,
                    'total' => count($atualizadas)
                ]),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? ''
            ]);
        }
        
        $response = [
            'success' => count($erros) === 0,
            'message' => count($erros) === 0 
                ? 'Configurações salvas com sucesso!' 
                : 'Algumas configurações não foram salvas',
            'atualizadas' => $atualizadas,
            'total_atualizadas' => count($atualizadas)
        ];
        
        if (count($erros) > 0) {
            $response['erros'] = $erros;
        }
        
        echo json_encode($response);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao salvar configurações: ' . $e->getMessage(),
            'atualizadas' => $atualizadas,
            'erros' => $erros
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
}

/**
 * Prepara o valor para armazenamento baseado no tipo
 */
function prepareValue($value, $type) {
    switch ($type) {
        case 'numero':
            return (string)(int)$value;
        
        case 'booleano':
            return $value ? 'true' : 'false';
        
        case 'json':
            return is_string($value) ? $value : json_encode($value);
        
        case 'data':
            // Validar formato de data
            if (strtotime($value) === false) {
                throw new Exception("Data inválida: {$value}");
            }
            return $value;
        
        default:
            return (string)$value;
    }
}