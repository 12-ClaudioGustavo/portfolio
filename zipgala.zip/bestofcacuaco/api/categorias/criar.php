<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

// Verificar autenticação
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $nome = $data['nome'] ?? '';
    $descricao = $data['descricao'] ?? '';
    $icone = $data['icone'] ?? 'fa-star';
    $cor = $data['cor'] ?? '#FFD700';
    $ordem = $data['ordem'] ?? 0;
    $ativo = isset($data['ativo']) ? $data['ativo'] : true;
    
    // Validações
    if (empty($nome)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Nome da categoria é obrigatório'
        ]);
        exit;
    }
    
    // Verificar se já existe categoria com este nome
    $categoriaExistente = $db->select('categorias', 'id', ['nome' => $nome]);
    if ($categoriaExistente && count($categoriaExistente) > 0) {
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'message' => 'Já existe uma categoria com este nome'
        ]);
        exit;
    }
    
    // Validar cor hexadecimal
    if (!preg_match('/^#[a-f0-9]{6}$/i', $cor)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Cor deve estar no formato hexadecimal (#FFFFFF)'
        ]);
        exit;
    }
    
    try {
        // Criar categoria
        $categoria = $db->insert('categorias', [
            'nome' => $nome,
            'descricao' => $descricao,
            'icone' => $icone,
            'cor' => $cor,
            'ordem' => (int)$ordem,
            'ativo' => $ativo
        ]);
        
        if ($categoria) {
            // Registrar na auditoria
            $db->insert('historico_acoes', [
                'acao' => 'criar',
                'tabela' => 'categorias',
                'registro_id' => $categoria[0]['id'] ?? null,
                'detalhes' => json_encode(['nome' => $nome]),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? ''
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Categoria criada com sucesso!',
                'data' => $categoria[0] ?? null
            ]);
        } else {
            throw new Exception('Erro ao criar categoria no banco de dados');
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao criar categoria: ' . $e->getMessage()
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
}