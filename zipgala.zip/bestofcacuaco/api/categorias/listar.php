<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

try {
    $filtros = [];
    
    // Filtro por status ativo
    if (isset($_GET['ativo'])) {
        $filtros['ativo'] = $_GET['ativo'] === 'true' ? 'true' : 'false';
    }
    
    // Buscar categorias
    $categorias = $db->select(
        'categorias', 
        'id,nome,descricao,icone,cor,ordem,ativo,created_at',
        $filtros
    );
    
    if ($categorias === false) {
        throw new Exception('Erro ao buscar categorias');
    }
    
    // Buscar contagem de candidatos por categoria
    foreach ($categorias as &$categoria) {
        $candidatos = $db->select('candidatos', 'COUNT(*) as total', [
            'categoria_id' => $categoria['id'],
            'ativo' => 'true'
        ]);
        
        $categoria['total_candidatos'] = $candidatos && count($candidatos) > 0 
            ? (int)$candidatos[0]['total'] 
            : 0;
        
        // Buscar total de votos
        $votos = $db->select('votos', 'COUNT(*) as total', [
            'categoria_id' => $categoria['id']
        ]);
        
        $categoria['total_votos'] = $votos && count($votos) > 0 
            ? (int)$votos[0]['total'] 
            : 0;
    }
    
    // Ordenar por campo 'ordem'
    usort($categorias, function($a, $b) {
        return $a['ordem'] <=> $b['ordem'];
    });
    
    echo json_encode([
        'success' => true,
        'data' => $categorias,
        'total' => count($categorias)
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar categorias: ' . $e->getMessage()
    ]);
}