<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

// Verificar autenticação
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'PUT' || $_SERVER['REQUEST_METHOD'] === 'PATCH') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $id = $data['id'] ?? null;
    
    if (!$id) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'ID do candidato é obrigatório'
        ]);
        exit;
    }
    
    // Verificar se candidato existe
    $candidatoExistente = $db->select('candidatos', '*', ['id' => $id]);
    if (!$candidatoExistente || count($candidatoExistente) === 0) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Candidato não encontrado'
        ]);
        exit;
    }
    
    // Preparar dados para atualização (apenas campos fornecidos)
    $updateData = [];
    
    if (isset($data['nome'])) {
        if (empty($data['nome'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Nome não pode ser vazio']);
            exit;
        }
        $updateData['nome'] = $data['nome'];
    }
    
    if (isset($data['categoria_id'])) {
        // Verificar se categoria existe
        $categoria = $db->select('categorias', 'id', ['id' => $data['categoria_id']]);
        if (!$categoria || count($categoria) === 0) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Categoria não encontrada']);
            exit;
        }
        $updateData['categoria_id'] = $data['categoria_id'];
    }
    
    if (isset($data['descricao_curta'])) {
        if (strlen($data['descricao_curta']) > 100) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Descrição curta muito longa']);
            exit;
        }
        $updateData['descricao_curta'] = $data['descricao_curta'];
    }
    
    if (isset($data['biografia'])) {
        $updateData['biografia'] = $data['biografia'];
    }
    
    if (isset($data['foto_url'])) {
        $updateData['foto_url'] = $data['foto_url'];
    }
    
    if (isset($data['ativo'])) {
        $updateData['ativo'] = $data['ativo'];
    }
    
    $updateData['updated_at'] = date('Y-m-d H:i:s');
    
    try {
        $resultado = $db->update('candidatos', $updateData, ['id' => $id]);
        
        if ($resultado !== false) {
            // Registrar na auditoria
            $db->insert('historico_acoes', [
                'acao' => 'editar',
                'tabela' => 'candidatos',
                'registro_id' => $id,
                'detalhes' => json_encode($updateData),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? ''
            ]);
            
            // Buscar candidato atualizado
            $candidatoAtualizado = $db->select('candidatos', '*', ['id' => $id]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Candidato atualizado com sucesso!',
                'data' => $candidatoAtualizado[0] ?? null
            ]);
        } else {
            throw new Exception('Erro ao atualizar candidato');
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao editar candidato: ' . $e->getMessage()
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
}