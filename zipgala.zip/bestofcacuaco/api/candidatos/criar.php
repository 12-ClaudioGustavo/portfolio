<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

// Verificar autenticação (simplificado)
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Token de autenticação não fornecido'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $nome = $data['nome'] ?? '';
    $categoriaId = $data['categoria_id'] ?? null;
    $descricaoCurta = $data['descricao_curta'] ?? '';
    $biografia = $data['biografia'] ?? '';
    $fotoUrl = $data['foto_url'] ?? '';
    $ativo = isset($data['ativo']) ? $data['ativo'] : true;
    
    // Validações
    if (empty($nome)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Nome é obrigatório'
        ]);
        exit;
    }
    
    if (empty($categoriaId)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Categoria é obrigatória'
        ]);
        exit;
    }
    
    if (empty($descricaoCurta)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Descrição curta é obrigatória'
        ]);
        exit;
    }
    
    if (empty($biografia)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Biografia é obrigatória'
        ]);
        exit;
    }
    
    // Validar tamanho da descrição curta
    if (strlen($descricaoCurta) > 100) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Descrição curta deve ter no máximo 100 caracteres'
        ]);
        exit;
    }
    
    // Verificar se categoria existe
    $categoria = $db->select('categorias', 'id', ['id' => $categoriaId]);
    if (!$categoria || count($categoria) === 0) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Categoria não encontrada'
        ]);
        exit;
    }
    
    try {
        // Criar candidato
        $candidato = $db->insert('candidatos', [
            'categoria_id' => $categoriaId,
            'nome' => $nome,
            'foto_url' => $fotoUrl,
            'biografia' => $biografia,
            'descricao_curta' => $descricaoCurta,
            'ativo' => $ativo,
            'total_votos' => 0
        ]);
        
        if ($candidato) {
            // Registrar na auditoria
            $db->insert('historico_acoes', [
                'acao' => 'criar',
                'tabela' => 'candidatos',
                'registro_id' => $candidato[0]['id'] ?? null,
                'detalhes' => json_encode([
                    'nome' => $nome,
                    'categoria_id' => $categoriaId
                ]),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? ''
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Candidato criado com sucesso!',
                'data' => $candidato[0] ?? null
            ]);
        } else {
            throw new Exception('Erro ao criar candidato no banco de dados');
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao criar candidato: ' . $e->getMessage()
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método não permitido'
    ]);
}