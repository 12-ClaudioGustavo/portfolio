<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

// Verificar autenticação
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // ID pode vir na URL ou no body
    $id = $_GET['id'] ?? null;
    
    if (!$id) {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? null;
    }
    
    if (!$id) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'ID do candidato é obrigatório'
        ]);
        exit;
    }
    
    try {
        // Verificar se candidato existe
        $candidato = $db->select('candidatos', 'id,nome', ['id' => $id]);
        
        if (!$candidato || count($candidato) === 0) {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'message' => 'Candidato não encontrado'
            ]);
            exit;
        }
        
        $nomeCandidato = $candidato[0]['nome'];
        
        // Verificar se há votos (opcional - comentar se quiser permitir deleção)
        $votos = $db->select('votos', 'COUNT(*) as total', ['candidato_id' => $id]);
        $totalVotos = $votos && count($votos) > 0 ? (int)$votos[0]['total'] : 0;
        
        if ($totalVotos > 0) {
            // Opção 1: Impedir deleção
            http_response_code(409);
            echo json_encode([
                'success' => false,
                'message' => "Não é possível deletar. O candidato possui {$totalVotos} voto(s) registrado(s).",
                'suggestion' => 'Você pode desativar o candidato ao invés de deletá-lo'
            ]);
            exit;
            
            // Opção 2: Deletar em cascata (descomente se preferir)
            // $db->delete('votos', ['candidato_id' => $id]);
        }
        
        // Deletar candidato
        $resultado = $db->delete('candidatos', ['id' => $id]);
        
        if ($resultado) {
            // Registrar na auditoria
            $db->insert('historico_acoes', [
                'acao' => 'deletar',
                'tabela' => 'candidatos',
                'registro_id' => $id,
                'detalhes' => json_encode([
                    'nome' => $nomeCandidato,
                    'votos_deletados' => $totalVotos
                ]),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? ''
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Candidato deletado com sucesso!',
                'deleted_id' => $id
            ]);
        } else {
            throw new Exception('Erro ao deletar candidato');
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao deletar candidato: ' . $e->getMessage()
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
}