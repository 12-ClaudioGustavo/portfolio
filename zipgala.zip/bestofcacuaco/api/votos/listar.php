<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Database;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

$db = new Database();

// Verificar autenticação
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

try {
    $filtros = [];
    
    // Filtros disponíveis
    if (isset($_GET['candidato_id'])) {
        $filtros['candidato_id'] = (int)$_GET['candidato_id'];
    }
    
    if (isset($_GET['categoria_id'])) {
        $filtros['categoria_id'] = (int)$_GET['categoria_id'];
    }
    
    if (isset($_GET['data_voto'])) {
        $filtros['data_voto'] = $_GET['data_voto'];
    }
    
    // Buscar votos
    $votos = $db->select('votos', '*', $filtros);
    
    if ($votos === false) {
        throw new Exception('Erro ao buscar votos');
    }
    
    // Enriquecer dados com informações de candidato e categoria
    foreach ($votos as &$voto) {
        // Buscar candidato
        $candidato = $db->select('candidatos', 'nome,foto_url', [
            'id' => $voto['candidato_id']
        ]);
        
        if ($candidato && count($candidato) > 0) {
            $voto['candidato_nome'] = $candidato[0]['nome'];
            $voto['candidato_foto'] = $candidato[0]['foto_url'];
        } else {
            $voto['candidato_nome'] = 'Desconhecido';
            $voto['candidato_foto'] = '';
        }
        
        // Buscar categoria
        $categoria = $db->select('categorias', 'nome,icone', [
            'id' => $voto['categoria_id']
        ]);
        
        if ($categoria && count($categoria) > 0) {
            $voto['categoria_nome'] = $categoria[0]['nome'];
            $voto['categoria_icone'] = $categoria[0]['icone'];
        } else {
            $voto['categoria_nome'] = 'Sem Categoria';
            $voto['categoria_icone'] = 'fa-question';
        }
        
        // Mascarar dispositivo_id e IP por privacidade
        $voto['dispositivo_id_masked'] = substr($voto['dispositivo_id'], 0, 8) . '...';
        $voto['ip_address_masked'] = maskIP($voto['ip_address']);
        
        // Remover dados sensíveis completos
        unset($voto['dispositivo_id']);
        unset($voto['ip_address']);
        unset($voto['user_agent']);
    }
    
    // Ordenação
    $orderBy = $_GET['order_by'] ?? 'created_at';
    $orderDir = $_GET['order_dir'] ?? 'desc';
    
    usort($votos, function($a, $b) use ($orderBy, $orderDir) {
        $result = $a[$orderBy] <=> $b[$orderBy];
        return $orderDir === 'desc' ? -$result : $result;
    });
    
    // Paginação
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $perPage = isset($_GET['per_page']) ? min(100, max(1, (int)$_GET['per_page'])) : 50;
    $total = count($votos);
    $totalPages = ceil($total / $perPage);
    
    $offset = ($page - 1) * $perPage;
    $votosPaginados = array_slice($votos, $offset, $perPage);
    
    echo json_encode([
        'success' => true,
        'data' => $votosPaginados,
        'pagination' => [
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_next' => $page < $totalPages,
            'has_prev' => $page > 1
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar votos: ' . $e->getMessage()
    ]);
}

/**
 * Mascara IP para privacidade
 */
function maskIP($ip) {
    if (empty($ip)) return '***.***.***.***.***';
    
    $parts = explode('.', $ip);
    if (count($parts) === 4) {
        return $parts[0] . '.***.***.***';
    }
    
    // IPv6
    return substr($ip, 0, 5) . '***';
}