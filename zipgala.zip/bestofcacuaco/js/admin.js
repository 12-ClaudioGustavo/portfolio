/**
 * Utilitários JavaScript para o Painel Administrativo
 * Gala de Premiação 2025
 */

// Configuração da API
const API_BASE_URL = '/api';
const AUTH_TOKEN_KEY = 'admin_token';

/**
 * Cliente HTTP para chamadas à API
 */
class APIClient {
    constructor() {
        this.baseURL = API_BASE_URL;
        this.token = localStorage.getItem(AUTH_TOKEN_KEY);
    }

    getHeaders() {
        const headers = {
            'Content-Type': 'application/json'
        };

        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        return headers;
    }

    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            ...options,
            headers: {
                ...this.getHeaders(),
                ...options.headers
            }
        };

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Erro na requisição');
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // Métodos HTTP
    get(endpoint, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const url = queryString ? `${endpoint}?${queryString}` : endpoint;
        return this.request(url, { method: 'GET' });
    }

    post(endpoint, data) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    put(endpoint, data) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    delete(endpoint, data = null) {
        return this.request(endpoint, {
            method: 'DELETE',
            body: data ? JSON.stringify(data) : null
        });
    }
}

// Instância global do cliente
const api = new APIClient();

/**
 * Gerenciador de Autenticação
 */
class AuthManager {
    static setToken(token) {
        localStorage.setItem(AUTH_TOKEN_KEY, token);
        api.token = token;
    }

    static getToken() {
        return localStorage.getItem(AUTH_TOKEN_KEY);
    }

    static removeToken() {
        localStorage.removeItem(AUTH_TOKEN_KEY);
        api.token = null;
    }

    static isAuthenticated() {
        return !!this.getToken();
    }

    static async login(email, password, remember = false) {
        try {
            const response = await api.post('/auth/login.php', {
                email,
                password,
                remember
            });

            if (response.success && response.token) {
                this.setToken(response.token);
                
                if (remember) {
                    localStorage.setItem('admin_email', email);
                }

                return response;
            }

            throw new Error(response.message || 'Erro no login');
        } catch (error) {
            throw error;
        }
    }

    static logout() {
        this.removeToken();
        window.location.href = 'login.html';
    }

    static checkAuth() {
        if (!this.isAuthenticated()) {
            window.location.href = 'login.html';
            return false;
        }
        return true;
    }
}

/**
 * Helpers de UI
 */
class UIHelpers {
    static showLoading(message = 'Carregando...') {
        Swal.fire({
            title: message,
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading(),
            background: '#1a1a1a',
            color: '#fff'
        });
    }

    static hideLoading() {
        Swal.close();
    }

    static showSuccess(title, message = '', timer = 2000) {
        return Swal.fire({
            icon: 'success',
            title,
            text: message,
            timer,
            showConfirmButton: timer === 0,
            background: '#1a1a1a',
            color: '#fff'
        });
    }

    static showError(title, message = '') {
        return Swal.fire({
            icon: 'error',
            title,
            text: message,
            background: '#1a1a1a',
            color: '#fff',
            confirmButtonColor: '#FFD700'
        });
    }

    static async confirm(title, message, confirmText = 'Sim', cancelText = 'Não') {
        const result = await Swal.fire({
            title,
            text: message,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: confirmText,
            cancelButtonText: cancelText,
            confirmButtonColor: '#FFD700',
            cancelButtonColor: '#d33',
            background: '#1a1a1a',
            color: '#fff'
        });

        return result.isConfirmed;
    }

    static formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('pt', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    static formatNumber(number) {
        return new Intl.NumberFormat('pt').format(number);
    }

    static truncate(text, maxLength = 100) {
        if (text.length <= maxLength) return text;
        return text.substr(0, maxLength) + '...';
    }

    static getStatusBadge(active) {
        const classes = active
            ? 'bg-green-500/20 text-green-400'
            : 'bg-red-500/20 text-red-400';
        const text = active ? 'Ativo' : 'Inativo';
        return `<span class="px-3 py-1 rounded-full text-xs ${classes}">${text}</span>`;
    }
}

/**
 * Gerenciador de Upload de Imagens
 */
class ImageUploader {
    constructor(inputId, previewId, maxSize = 5 * 1024 * 1024) {
        this.input = document.getElementById(inputId);
        this.preview = document.getElementById(previewId);
        this.maxSize = maxSize;
        this.currentFile = null;
    }

    init() {
        if (!this.input || !this.preview) return;

        this.input.addEventListener('change', (e) => this.handleFileSelect(e));
    }

    handleFileSelect(event) {
        const file = event.target.files[0];
        if (!file) return;

        // Validar tipo
        if (!file.type.startsWith('image/')) {
            UIHelpers.showError('Erro', 'Por favor, selecione uma imagem válida');
            return;
        }

        // Validar tamanho
        if (file.size > this.maxSize) {
            const maxMB = this.maxSize / (1024 * 1024);
            UIHelpers.showError('Erro', `Imagem muito grande. Máximo: ${maxMB}MB`);
            return;
        }

        this.currentFile = file;
        this.previewImage(file);
    }

    previewImage(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            this.preview.src = e.target.result;
            this.preview.classList.remove('hidden');
        };
        reader.readAsDataURL(file);
    }

    async upload(endpoint = '/api/upload.php') {
        if (!this.currentFile) {
            throw new Error('Nenhuma imagem selecionada');
        }

        const formData = new FormData();
        formData.append('image', this.currentFile);

        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${AuthManager.getToken()}`
                },
                body: formData
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Erro no upload');
            }

            return data.url;
        } catch (error) {
            console.error('Upload error:', error);
            throw error;
        }
    }

    getBase64() {
        return this.preview.src;
    }

    reset() {
        this.currentFile = null;
        this.preview.src = '';
        this.preview.classList.add('hidden');
        if (this.input) this.input.value = '';
    }
}

/**
 * Gerenciador de Tabelas
 */
class TableManager {
    constructor(tableId, data = []) {
        this.table = document.getElementById(tableId);
        this.tbody = this.table?.querySelector('tbody');
        this.data = data;
        this.currentPage = 1;
        this.perPage = 10;
    }

    setData(data) {
        this.data = data;
        this.render();
    }

    render(renderFunction) {
        if (!this.tbody) return;

        const start = (this.currentPage - 1) * this.perPage;
        const end = start + this.perPage;
        const paginatedData = this.data.slice(start, end);

        if (paginatedData.length === 0) {
            this.tbody.innerHTML = `
                <tr>
                    <td colspan="100" class="px-6 py-12 text-center text-gray-400">
                        Nenhum registro encontrado
                    </td>
                </tr>
            `;
            return;
        }

        this.tbody.innerHTML = paginatedData.map(renderFunction).join('');
    }

    updatePagination(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const totalPages = Math.ceil(this.data.length / this.perPage);
        
        container.innerHTML = '';

        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement('button');
            btn.textContent = i;
            btn.className = `px-4 py-2 rounded ${
                i === this.currentPage 
                    ? 'bg-yellow-400 text-black' 
                    : 'bg-gray-800 hover:bg-gray-700'
            }`;
            btn.onclick = () => {
                this.currentPage = i;
                this.render();
                this.updatePagination(containerId);
            };
            container.appendChild(btn);
        }
    }
}

/**
 * Validador de Formulários
 */
class FormValidator {
    static validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    static validateURL(url) {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    }

    static validateRequired(value) {
        return value !== null && value !== undefined && value.toString().trim() !== '';
    }

    static validateMinLength(value, min) {
        return value.length >= min;
    }

    static validateMaxLength(value, max) {
        return value.length <= max;
    }

    static validateForm(formId, rules) {
        const form = document.getElementById(formId);
        if (!form) return { valid: false, errors: ['Formulário não encontrado'] };

        const errors = [];

        for (const [fieldId, fieldRules] of Object.entries(rules)) {
            const field = document.getElementById(fieldId);
            if (!field) continue;

            const value = field.value;

            if (fieldRules.required && !this.validateRequired(value)) {
                errors.push(`${fieldRules.label || fieldId} é obrigatório`);
            }

            if (fieldRules.email && !this.validateEmail(value)) {
                errors.push(`${fieldRules.label || fieldId} deve ser um email válido`);
            }

            if (fieldRules.minLength && !this.validateMinLength(value, fieldRules.minLength)) {
                errors.push(`${fieldRules.label || fieldId} deve ter no mínimo ${fieldRules.minLength} caracteres`);
            }

            if (fieldRules.maxLength && !this.validateMaxLength(value, fieldRules.maxLength)) {
                errors.push(`${fieldRules.label || fieldId} deve ter no máximo ${fieldRules.maxLength} caracteres`);
            }

            if (fieldRules.url && value && !this.validateURL(value)) {
                errors.push(`${fieldRules.label || fieldId} deve ser uma URL válida`);
            }
        }

        return {
            valid: errors.length === 0,
            errors
        };
    }
}

/**
 * Exportar Dados
 */
class DataExporter {
    static toCSV(data, filename = 'export.csv') {
        if (!data || data.length === 0) {
            UIHelpers.showError('Erro', 'Nenhum dado para exportar');
            return;
        }

        const headers = Object.keys(data[0]);
        const csvContent = [
            headers.join(','),
            ...data.map(row => 
                headers.map(header => 
                    JSON.stringify(row[header] || '')
                ).join(',')
            )
        ].join('\n');

        this.download(csvContent, filename, 'text/csv');
    }

    static toJSON(data, filename = 'export.json') {
        const content = JSON.stringify(data, null, 2);
        this.download(content, filename, 'application/json');
    }

    static download(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }
}

// Exportar para uso global
window.api = api;
window.AuthManager = AuthManager;
window.UIHelpers = UIHelpers;
window.ImageUploader = ImageUploader;
window.TableManager = TableManager;
window.FormValidator = FormValidator;
window.DataExporter = DataExporter;