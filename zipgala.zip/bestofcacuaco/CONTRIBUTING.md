# 🤝 Contribuindo para Gala de Premiação 2025

Obrigado por considerar contribuir para este projeto! Este documento fornece diretrizes para contribuições.

## 📋 Código de Conduta

Ao participar deste projeto, você concorda em manter um ambiente respeitoso e profissional.

### Esperamos que você:
- ✅ Seja respeitoso com outros contribuidores
- ✅ Aceite feedback construtivo
- ✅ Foque no que é melhor para a comunidade
- ✅ Mostre empatia com outros membros

### Não toleramos:
- ❌ Linguagem ou imagens ofensivas
- ❌ Ataques pessoais ou políticos
- ❌ Assédio público ou privado
- ❌ Publicar informações privadas de outros

## 🚀 Como Contribuir

### Reportar Bugs

Se encontrar um bug, por favor crie uma issue com:

1. **Título claro e descritivo**
2. **Passos para reproduzir** o problema
3. **Comportamento esperado** vs **comportamento atual**
4. **Screenshots** (se aplicável)
5. **Informações do ambiente**:
   - Navegador e versão
   - Sistema operacional
   - Versão do PHP
   - Mensagens de erro

**Exemplo:**

```markdown
### Descrição
Ao tentar votar, recebo erro 500

### Passos para Reproduzir
1. Acesse a página de votação
2. Selecione um candidato
3. Clique em "Votar"

### Comportamento Esperado
Voto deveria ser registrado com sucesso

### Comportamento Atual
Erro 500 é exibido

### Ambiente
- Navegador: Chrome 120
- OS: Windows 11
- PHP: 8.1.0
```

### Sugerir Melhorias

Para sugerir uma nova funcionalidade:

1. **Verifique** se já não existe uma issue similar
2. **Crie uma issue** com o template:
   - Problema que resolve
   - Solução proposta
   - Alternativas consideradas
3. **Aguarde feedback** antes de começar a implementar

### Pull Requests

#### Antes de Submeter

1. **Fork** o repositório
2. **Crie um branch** descritivo:
   ```bash
   git checkout -b feature/nova-funcionalidade
   # ou
   git checkout -b fix/corrigir-bug
   ```

3. **Faça commits** atômicos e bem descritos:
   ```bash
   git commit -m "feat: adiciona filtro por data na votação"
   git commit -m "fix: corrige erro ao salvar categoria"
   git commit -m "docs: atualiza README com novas instruções"
   ```

#### Padrão de Commits

Usamos o padrão [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` - Nova funcionalidade
- `fix:` - Correção de bug
- `docs:` - Mudanças na documentação
- `style:` - Formatação, ponto e vírgula, etc
- `refactor:` - Refatoração de código
- `test:` - Adição de testes
- `chore:` - Tarefas de manutenção

**Exemplos:**
```
feat(votacao): adiciona verificação de dispositivo
fix(api): corrige cálculo de votos duplicados
docs(readme): adiciona instruções de deploy
style(css): padroniza espaçamento
refactor(database): melhora consultas SQL
test(api): adiciona testes para endpoint de votos
chore(deps): atualiza dependências
```

#### Checklist do Pull Request

- [ ] Código segue o estilo do projeto
- [ ] Commits seguem o padrão Conventional Commits
- [ ] Código foi testado localmente
- [ ] Documentação foi atualizada (se necessário)
- [ ] Não há conflitos com a branch main
- [ ] Pull Request tem descrição clara

#### Template do Pull Request

```markdown
## Descrição
[Descreva brevemente as mudanças]

## Tipo de Mudança
- [ ] Bug fix (mudança que corrige um problema)
- [ ] Nova funcionalidade (mudança que adiciona funcionalidade)
- [ ] Breaking change (mudança que quebra compatibilidade)
- [ ] Documentação

## Como Testar
1. [Primeiro passo]
2. [Segundo passo]
3. [...]

## Screenshots
[Se aplicável, adicione screenshots]

## Checklist
- [ ] Meu código segue o estilo deste projeto
- [ ] Revisei meu próprio código
- [ ] Comentei áreas complexas do código
- [ ] Atualizei a documentação
- [ ] Minhas mudanças não geram novos warnings
- [ ] Adicionei testes que provam que minha correção funciona
- [ ] Testes novos e existentes passam localmente
```

## 🎨 Estilo de Código

### PHP

```php
<?php
// Use PSR-12
// Indentação: 4 espaços
// Chaves na mesma linha para funções e classes

class MinhaClasse 
{
    private $propriedade;
    
    public function meuMetodo($parametro) 
    {
        if ($condicao) {
            // código
        }
        
        return $resultado;
    }
}
```

### JavaScript

```javascript
// Use ES6+
// Indentação: 4 espaços ou 2 espaços (seja consistente)
// Use const/let ao invés de var
// Use arrow functions quando apropriado

const minhaFuncao = (parametro) => {
    if (condicao) {
        // código
    }
    
    return resultado;
};
```

### CSS/Tailwind

```html
<!-- Use classes do Tailwind quando possível -->
<!-- Organize classes por tipo: layout, spacing, colors, etc -->
<div class="flex items-center justify-between px-6 py-4 bg-gray-900 text-white rounded-lg">
    <!-- conteúdo -->
</div>
```

### SQL

```sql
-- Use maiúsculas para comandos SQL
-- Indente subconsultas
-- Use nomes descritivos

SELECT 
    c.nome,
    c.total_votos,
    cat.nome AS categoria_nome
FROM candidatos c
INNER JOIN categorias cat ON c.categoria_id = cat.id
WHERE c.ativo = true
ORDER BY c.total_votos DESC
LIMIT 10;
```

## 🧪 Testes

### Estrutura de Testes

```
tests/
├── Unit/           # Testes unitários
├── Integration/    # Testes de integração
└── Feature/        # Testes de funcionalidade
```

### Executar Testes

```bash
# Todos os testes
composer test

# Testes específicos
composer test -- --filter=VotacaoTest
```

### Escrever Testes

```php
<?php
use PHPUnit\Framework\TestCase;

class VotacaoTest extends TestCase
{
    public function testDeveRegistrarVoto()
    {
        // Arrange
        $candidatoId = 1;
        $dispositivoId = 'abc123';
        
        // Act
        $resultado = registrarVoto($candidatoId, $dispositivoId);
        
        // Assert
        $this->assertTrue($resultado['success']);
    }
}
```

## 📁 Estrutura do Projeto

```
gala-premiacao-2025/
├── api/                  # Endpoints da API
│   ├── auth/            # Autenticação
│   ├── categorias/      # CRUD de categorias
│   ├── candidatos/      # CRUD de candidatos
│   ├── stats/           # Estatísticas
│   └── votar.php        # Endpoint de votação
├── admin/               # Painel administrativo
├── src/                 # Classes PHP
│   └── Database.php     # Classe de banco de dados
├── js/                  # JavaScript
├── uploads/             # Uploads de arquivos
├── vendor/              # Dependências do Composer
├── .env.example         # Exemplo de configuração
├── .htaccess            # Configuração Apache
├── composer.json        # Dependências PHP
├── index.html           # Página inicial
├── indicados.html       # Página de indicados
├── votacao.html         # Página de votação
└── sobre.html           # Página sobre
```

## 🔐 Segurança

### Reportar Vulnerabilidades

**NÃO** crie issues públicas para vulnerabilidades de segurança.

Envie um email para: **security@seudominio.com**

Inclua:
- Descrição da vulnerabilidade
- Passos para reproduzir
- Impacto potencial
- Sugestões de correção (se tiver)

### Práticas de Segurança

- ✅ Nunca commite credenciais ou chaves de API
- ✅ Use prepared statements para SQL
- ✅ Valide e sanitize todas as entradas
- ✅ Use HTTPS em produção
- ✅ Mantenha dependências atualizadas

## 📝 Documentação

### Comentários no Código

```php
/**
 * Registra um voto para um candidato
 *
 * @param int $candidatoId ID do candidato
 * @param string $dispositivoId Identificador único do dispositivo
 * @return array ['success' => bool, 'message' => string]
 * @throws Exception Se houver erro na conexão
 */
function registrarVoto($candidatoId, $dispositivoId) {
    // implementação
}
```

### README e Documentação

- Mantenha o README.md atualizado
- Documente novas funcionalidades
- Adicione exemplos de uso
- Atualize o CHANGELOG.md

## 🎯 Prioridades

### Alta Prioridade
- 🔴 Correção de bugs críticos
- 🔴 Problemas de segurança
- 🔴 Perda de dados

### Média Prioridade
- 🟡 Novas funcionalidades
- 🟡 Melhorias de performance
- 🟡 Refatorações

### Baixa Prioridade
- 🟢 Melhorias visuais
- 🟢 Documentação
- 🟢 Testes adicionais

## 📞 Comunicação

### Canais

- **GitHub Issues**: Para bugs e features
- **GitHub Discussions**: Para perguntas e ideias
- **Email**: suporte@seudominio.com

### Tempo de Resposta

- Issues críticas: 24 horas
- Pull requests: 48-72 horas
- Perguntas gerais: 1 semana

## 🏆 Reconhecimento

Contribuidores serão listados em:
- README.md na seção "Contribuidores"
- Changelog em cada release
- Página "Sobre" do site (opcional)

## 📜 Licença

Ao contribuir, você concorda que suas contribuições serão licenciadas sob a mesma licença do projeto (MIT).

---

**Obrigado por contribuir! 🎉**

Cada contribuição, não importa o tamanho, é valiosa e apreciada.