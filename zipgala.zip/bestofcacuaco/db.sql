-- Tabela de configurações do site
CREATE TABLE configuracoes (
    id SERIAL PRIMARY KEY,
    chave VARCHAR(100) UNIQUE NOT NULL,
    valor TEXT,
    descricao TEXT,
    tipo VARCHAR(50), -- 'texto', 'numero', 'data', 'json', 'booleano'
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de administradores
CREATE TABLE administradores (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    nivel_acesso VARCHAR(50) DEFAULT 'admin', -- 'superadmin', 'admin', 'moderador'
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de categorias
CREATE TABLE categorias (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    icone VARCHAR(100), -- classe do fontawesome
    cor VARCHAR(50), -- cor em hexadecimal
    ordem INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de candidatos/indicados
CREATE TABLE candidatos (
    id SERIAL PRIMARY KEY,
    categoria_id INTEGER REFERENCES categorias(id) ON DELETE CASCADE,
    nome VARCHAR(255) NOT NULL,
    foto_url TEXT,
    biografia TEXT,
    descricao_curta TEXT,
    total_votos INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Índice para melhorar performance
CREATE INDEX idx_candidatos_categoria ON candidatos(categoria_id);

-- Tabela de votos
CREATE TABLE votos (
    id SERIAL PRIMARY KEY,
    candidato_id INTEGER REFERENCES candidatos(id) ON DELETE CASCADE,
    categoria_id INTEGER REFERENCES categorias(id) ON DELETE CASCADE,
    dispositivo_id VARCHAR(255) NOT NULL, -- fingerprint do dispositivo
    ip_address VARCHAR(45),
    user_agent TEXT,
    data_voto DATE DEFAULT CURRENT_DATE,
    hora_voto TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Índices para verificação de votos duplicados e estatísticas
CREATE INDEX idx_votos_dispositivo_data ON votos(dispositivo_id, data_voto);
CREATE INDEX idx_votos_candidato ON votos(candidato_id);
CREATE INDEX idx_votos_categoria ON votos(categoria_id);
CREATE UNIQUE INDEX idx_votos_unique_daily ON votos(dispositivo_id, categoria_id, data_voto);

-- Tabela de organizações parceiras
CREATE TABLE organizacoes (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    logo_url TEXT,
    descricao TEXT,
    website VARCHAR(255),
    ordem INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de mídia (fotos/vídeos da gala anterior)
CREATE TABLE midia_gala (
    id SERIAL PRIMARY KEY,
    tipo VARCHAR(50), -- 'foto', 'video'
    url TEXT NOT NULL,
    titulo VARCHAR(255),
    descricao TEXT,
    ano INTEGER,
    ordem INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de histórico de ações (auditoria)
CREATE TABLE historico_acoes (
    id SERIAL PRIMARY KEY,
    admin_id INTEGER REFERENCES administradores(id),
    acao VARCHAR(100), -- 'criar', 'editar', 'deletar', 'votar'
    tabela VARCHAR(100),
    registro_id INTEGER,
    detalhes JSONB,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Inserir configurações iniciais
INSERT INTO configuracoes (chave, valor, descricao, tipo) VALUES
('site_titulo', 'Gala de Premiação 2025', 'Título principal do site', 'texto'),
('data_gala', '2025-12-31 20:00:00', 'Data e hora da gala', 'data'),
('votacao_ativa', 'true', 'Controla se a votação está aberta', 'booleano'),
('data_inicio_votacao', '2025-11-01', 'Data de início das votações', 'data'),
('data_fim_votacao', '2025-12-30', 'Data de fim das votações', 'data'),
('tema_automatico', 'true', 'Ativar modo noturno automático', 'booleano'),
('horario_tema_noturno', '18:00', 'Horário para ativar tema noturno', 'texto'),
('mostrar_confete', 'true', 'Mostrar confete ao votar', 'booleano'),
('cor_primaria', '#FFD700', 'Cor dourada principal', 'texto'),
('video_hero_url', '', 'URL do vídeo de fundo da hero', 'texto'),
('sobre_texto', 'Nossa gala celebra os melhores talentos...', 'Texto da página sobre', 'texto'),
('impacto_social', '{"projetos": 50, "beneficiados": 10000, "anos": 5}', 'Dados de impacto social', 'json');

-- Função para atualizar contador de votos
CREATE OR REPLACE FUNCTION atualizar_total_votos()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE candidatos 
    SET total_votos = (
        SELECT COUNT(*) 
        FROM votos 
        WHERE candidato_id = NEW.candidato_id
    )
    WHERE id = NEW.candidato_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar votos automaticamente
CREATE TRIGGER trigger_atualizar_votos
AFTER INSERT ON votos
FOR EACH ROW
EXECUTE FUNCTION atualizar_total_votos();

-- Função para limpar votos antigos (opcional, para manutenção)
CREATE OR REPLACE FUNCTION limpar_votos_antigos(dias INTEGER DEFAULT 365)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM votos 
    WHERE created_at < NOW() - INTERVAL '1 day' * dias;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- View para estatísticas rápidas
CREATE VIEW estatisticas_votacao AS
SELECT 
    c.id as categoria_id,
    c.nome as categoria_nome,
    COUNT(DISTINCT v.dispositivo_id) as total_votantes,
    COUNT(v.id) as total_votos,
    COUNT(DISTINCT DATE(v.data_voto)) as dias_votacao
FROM categorias c
LEFT JOIN votos v ON c.id = v.categoria_id
GROUP BY c.id, c.nome;

-- View para ranking de candidatos por categoria
CREATE VIEW ranking_candidatos AS
SELECT 
    ca.id as candidato_id,
    ca.nome as candidato_nome,
    ca.foto_url,
    c.id as categoria_id,
    c.nome as categoria_nome,
    ca.total_votos,
    RANK() OVER (PARTITION BY c.id ORDER BY ca.total_votos DESC) as posicao
FROM candidatos ca
JOIN categorias c ON ca.categoria_id = c.id
WHERE ca.ativo = true
ORDER BY c.nome, ca.total_votos DESC;