# 🏆 Gala de Premiação 2025 - Sistema de Votação

Sistema completo para gestão e votação de uma gala de premiação, com interface moderna, efeitos visuais dourados e sistema de votação por dispositivo.

## ✨ Funcionalidades

### Frontend
- 🎬 **Página Inicial** - Hero section com vídeo de fundo, contagem regressiva animada e efeitos de partículas douradas
- 📖 **Página Sobre** - Histórico do projeto e impacto social
- 🎭 **Página de Indicados** - Listagem com filtros por categoria
- 🗳️ **Sistema de Votação** - Vote uma vez por dia em cada categoria
- 🎊 **Confete Animado** - Celebração visual ao votar com sucesso
- 🌙 **Modo Noturno Automático** - Ajusta tema baseado no horário local
- 📱 **QR Code** - Acesso rápido à votação
- 📊 **Dashboard Admin** - Gestão completa do sistema

### Backend
- 🔐 **Autenticação Segura** - Sistema de login para administradores
- 👥 **Gestão de Candidatos** - CRUD completo
- 🏷️ **Gestão de Categorias** - Personalização total
- 📈 **Estatísticas em Tempo Real** - Acompanhamento de votos
- 🔍 **Auditoria** - Log completo de todas as ações
- 🛡️ **Proteção contra Fraude** - Fingerprint de dispositivo + limite diário

## 🛠️ Tecnologias

### Frontend
- HTML5
- TailwindCSS
- JavaScript (Vanilla)
- SweetAlert2
- AOS.js (Animações on scroll)
- Font Awesome
- Google Fonts (Playfair Display + Poppins)

### Backend
- PHP 8.0+
- Composer
- GuzzleHTTP
- Supabase (PostgreSQL)
- DotEnv

## 📦 Instalação

### 1. Requisitos
```bash
- PHP 8.0 ou superior
- Composer
- Conta no Supabase
- Servidor web (Apache/Nginx)
```

### 2. Clone o repositório
```bash
git clone https://github.com/seu-usuario/gala-premiacao-2025.git
cd gala-premiacao-2025
```

### 3. Instale as dependências
```bash
composer install
```

### 4. Configure o ambiente
```bash
cp .env.example .env
```

Edite o arquivo `.env` com suas credenciais:
```env
SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_KEY=sua_chave_anon_aqui
SITE_URL=https://seusite.com
SESSION_SECRET=gere_uma_chave_secreta_forte
```

### 5. Configure o banco de dados

Acesse o Supabase e execute o script SQL em `gala_db_structure.sql` para criar todas as tabelas, views e triggers.

### 6. Crie o primeiro administrador

Execute o seguinte SQL no Supabase:
```sql
INSERT INTO administradores (nome, email, senha, nivel_acesso) 
VALUES (
    'Admin', 
    'admin@seusite.com', 
    '$2y$10$' || md5('sua_senha_aqui'),
    'superadmin'
);
```

### 7. Configure o servidor web

**Apache (.htaccess)**
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^api/(.*)$ api/$1.php [L]
```

**Nginx**
```nginx
location /api/ {
    try_files $uri $uri/ /api/$uri.php?$args;
}
```

## 🚀 Uso

### Acessar o site
```
https://seusite.com
```

### Acessar área administrativa
```
https://seusite.com/admin/login.html

Credenciais padrão:
Email: admin@seusite.com
Senha: (a que você configurou)
```

## 📂 Estrutura de Pastas

```
gala-premiacao-2025/
├── api/
│   ├── votar.php
│   ├── categorias/
│   │   ├── listar.php
│   │   ├── criar.php
│   │   └── editar.php
│   ├── candidatos/
│   │   ├── listar.php
│   │   ├── criar.php
│   │   └── editar.php
│   ├── auth/
│   │   ├── login.php
│   │   └── verify.php
│   └── stats/
│       └── dashboard.php
├── admin/
│   ├── login.html
│   ├── dashboard.html
│   ├── categorias.html
│   ├── candidatos.html
│   └── estatisticas.html
├── src/
│   └── Database.php
├── js/
│   ├── fingerprint.js
│   └── admin.js
├── css/
│   └── custom.css
├── index.html
├── sobre.html
├── indicados.html
├── votacao.html
├── composer.json
├── .env.example
└── README.md
```

## 🔒 Segurança

### Proteção contra votação múltipla
O sistema implementa 3 camadas de proteção:

1. **Device Fingerprinting** - Identificação única do dispositivo usando:
   - User Agent
   - Canvas fingerprint
   - WebGL fingerprint
   - Resolução de tela
   - Timezone
   - Fontes disponíveis
   
2. **Limite Diário** - Banco de dados com constraint UNIQUE impedindo múltiplos votos no mesmo dia

3. **IP Tracking** - Registro de IP para auditoria (não usado como bloqueio principal devido a IPs dinâmicos)

### Autenticação Admin
- Senhas hasheadas com bcrypt
- Tokens JWT para sessões
- Logs de todas as ações administrativas
- Verificação de nível de acesso

## 📊 Configurações Dinâmicas

Todas as configurações podem ser alteradas através do banco de dados na tabela `configuracoes`:

```sql
-- Ativar/desativar votação
UPDATE configuracoes SET valor = 'true' WHERE chave = 'votacao_ativa';

-- Alterar data da gala
UPDATE configuracoes SET valor = '2025-12-31 20:00:00' WHERE chave = 'data_gala';

-- Alterar período de votação
UPDATE configuracoes SET valor = '2025-11-01' WHERE chave = 'data_inicio_votacao';
UPDATE configuracoes SET valor = '2025-12-30' WHERE chave = 'data_fim_votacao';

-- URL do vídeo hero
UPDATE configuracoes SET valor = 'https://seu-video.mp4' WHERE chave = 'video_hero_url';

-- Ativar confete
UPDATE configuracoes SET valor = 'true' WHERE chave = 'mostrar_confete';
```

## 🎨 Personalização

### Cores
Edite as variáveis CSS no arquivo `index.html` ou crie um `custom.css`:

```css
:root {
    --gold: #FFD700;
    --dark-gold: #B8860B;
    --dark-bg: #0a0a0a;
}
```

### Fontes
As fontes estão configuradas no Google Fonts:
- **Títulos**: Playfair Display
- **Corpo**: Poppins

Para alterar, edite a importação no `<head>`:
```html
<link href="https://fonts.googleapis.com/css2?family=SuaFonte&display=swap" rel="stylesheet">
```

## 📱 Responsividade

O site é totalmente responsivo, testado em:
- 📱 Mobile (320px+)
- 📱 Tablet (768px+)
- 💻 Desktop (1024px+)
- 🖥️ Large Desktop (1440px+)

## 🐛 Troubleshooting

### Votos não estão sendo registrados
1. Verifique se `votacao_ativa` está como `true`
2. Confirme o período de votação nas configurações
3. Verifique os logs do PHP para erros
4. Teste a conexão com o Supabase

### Efeitos visuais não aparecem
1. Limpe o cache do navegador
2. Verifique se o JavaScript está habilitado
3. Abra o console para ver erros

### Erro ao fazer login
1. Verifique as credenciais no banco
2. Confirme que o hash da senha está correto
3. Verifique a configuração do JWT_SECRET

## 📈 Estatísticas

O sistema oferece diversas métricas:
- Total de votos por categoria
- Total de votantes únicos
- Ranking de candidatos
- Gráficos de evolução temporal
- Distribuição geográfica (se configurado)

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/MinhaFeature`)
3. Commit suas mudanças (`git commit -m 'Adiciona MinhaFeature'`)
4. Push para a branch (`git push origin feature/MinhaFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 👨‍💻 Autor

Desenvolvido com ❤️ para a Gala de Premiação 2025

## 📞 Suporte

Para suporte, entre em contato:
- Email: suporte@gala2025.com
- GitHub Issues: [Reportar Bug](https://github.com/seu-usuario/gala-premiacao-2025/issues)

---

⭐ Se este projeto foi útil, considere dar uma estrela no GitHub!