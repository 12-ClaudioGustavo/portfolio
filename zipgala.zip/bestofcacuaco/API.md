# 📡 Documentação da API - Gala de Premiação 2025

Documentação completa de todos os endpoints da API REST.

## 🔐 Autenticação

A maioria dos endpoints requer autenticação via token JWT no header:

```
Authorization: Bearer {seu_token_aqui}
```

### Login

**POST** `/api/auth/login.php`

Autentica um administrador e retorna um token JWT.

**Request Body:**
```json
{
  "email": "admin@gala.com",
  "password": "senha_forte",
  "remember": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login realizado com sucesso",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "nome": "Admin",
    "email": "admin@gala.com",
    "nivel_acesso": "superadmin"
  }
}
```

---

## 📊 Categorias

### Listar Categorias

**GET** `/api/categorias/listar.php`

Lista todas as categorias com estatísticas.

**Query Parameters:**
- `ativo` (opcional): `true` | `false`

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "nome": "Melhor Ator",
      "descricao": "Reconhece atuação masculina",
      "icone": "fa-user-tie",
      "cor": "#FFD700",
      "ordem": 1,
      "ativo": true,
      "total_candidatos": 5,
      "total_votos": 1200,
      "created_at": "2025-01-15 10:00:00"
    }
  ],
  "total": 5
}
```

### Criar Categoria

**POST** `/api/categorias/criar.php`

🔒 Requer autenticação

**Request Body:**
```json
{
  "nome": "Nova Categoria",
  "descricao": "Descrição da categoria",
  "icone": "fa-star",
  "cor": "#FFD700",
  "ordem": 1,
  "ativo": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Categoria criada com sucesso!",
  "data": {
    "id": 6,
    "nome": "Nova Categoria",
    ...
  }
}
```

**Validações:**
- `nome`: Obrigatório, único
- `cor`: Formato hexadecimal (#FFFFFF)
- `icone`: String (classe Font Awesome)

---

## 👥 Candidatos

### Listar Candidatos

**GET** `/api/candidatos/listar.php`

Lista candidatos com filtros e paginação.

**Query Parameters:**
- `categoria_id` (opcional): Filtrar por categoria
- `ativo` (opcional): `true` | `false`
- `page` (opcional): Número da página (default: 1)
- `per_page` (opcional): Itens por página (default: 20, max: 100)
- `order_by` (opcional): `nome` | `total_votos` | `created_at`
- `order_dir` (opcional): `asc` | `desc`

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "categoria_id": 1,
      "nome": "João Silva",
      "foto_url": "https://...",
      "biografia": "Biografia completa...",
      "descricao_curta": "Ator talentoso",
      "total_votos": 1250,
      "votos_hoje": 45,
      "ativo": true,
      "categoria_nome": "Melhor Ator",
      "categoria_icone": "fa-user-tie",
      "categoria_cor": "#FFD700",
      "created_at": "2025-01-15 10:00:00"
    }
  ],
  "pagination": {
    "current_page": 1,
    "per_page": 20,
    "total": 45,
    "total_pages": 3,
    "has_next": true,
    "has_prev": false
  }
}
```

### Criar Candidato

**POST** `/api/candidatos/criar.php`

🔒 Requer autenticação

**Request Body:**
```json
{
  "nome": "Nome do Candidato",
  "categoria_id": 1,
  "descricao_curta": "Descrição em até 100 caracteres",
  "biografia": "Biografia completa do candidato...",
  "foto_url": "https://exemplo.com/foto.jpg",
  "ativo": true
}
```

**Validações:**
- `nome`: Obrigatório
- `categoria_id`: Obrigatório, deve existir
- `descricao_curta`: Obrigatório, máx 100 caracteres
- `biografia`: Obrigatório

### Editar Candidato

**PUT/PATCH** `/api/candidatos/editar.php`

🔒 Requer autenticação

**Request Body:**
```json
{
  "id": 1,
  "nome": "Nome Atualizado",
  "descricao_curta": "Nova descrição",
  "ativo": true
}
```

_Nota: Envie apenas os campos que deseja atualizar_

### Deletar Candidato

**DELETE** `/api/candidatos/deletar.php?id=1`

🔒 Requer autenticação

**Response:**
```json
{
  "success": true,
  "message": "Candidato deletado com sucesso!",
  "deleted_id": 1
}
```

**Regra de Negócio:**
- Se o candidato possui votos, não pode ser deletado
- Sugestão: Desativar ao invés de deletar

---

## 🗳️ Votação

### Registrar Voto

**POST** `/api/votar.php`

Registra um voto para um candidato.

**Request Body:**
```json
{
  "candidato_id": 1,
  "categoria_id": 1,
  "dispositivo_id": "abc123xyz789"
}
```

**Response Success:**
```json
{
  "success": true,
  "message": "Voto registrado com sucesso!",
  "showConfetti": true
}
```

**Response Error (já votou hoje):**
```json
{
  "success": false,
  "message": "Você já votou nesta categoria hoje. Volte amanhã!"
}
```

**Validações:**
- Votação deve estar ativa
- Dentro do período de votação
- Dispositivo só pode votar 1x por dia por categoria
- Candidato deve pertencer à categoria
- Candidato deve estar ativo

### Listar Votos (Admin)

**GET** `/api/votos/listar.php`

🔒 Requer autenticação

**Query Parameters:**
- `candidato_id` (opcional)
- `categoria_id` (opcional)
- `data_voto` (opcional): formato YYYY-MM-DD
- `page` (opcional)
- `per_page` (opcional)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "candidato_id": 1,
      "candidato_nome": "João Silva",
      "candidato_foto": "https://...",
      "categoria_id": 1,
      "categoria_nome": "Melhor Ator",
      "categoria_icone": "fa-user-tie",
      "dispositivo_id_masked": "abc123...",
      "ip_address_masked": "197.***.***.***",
      "data_voto": "2025-11-14",
      "hora_voto": "2025-11-14 15:23:45",
      "created_at": "2025-11-14 15:23:45"
    }
  ],
  "pagination": {...}
}
```

_Nota: Por privacidade, dispositivo_id e IP são mascarados_

---

## ⚙️ Configurações

### Obter Configurações

**GET** `/api/configuracoes/obter.php`

Obtém todas as configurações ou uma específica.

**Query Parameters:**
- `chave` (opcional): Buscar configuração específica

**Response (todas):**
```json
{
  "success": true,
  "data": {
    "geral": [
      {
        "chave": "site_titulo",
        "valor": "Gala de Premiação 2025",
        "tipo": "texto",
        "descricao": "Título principal do site"
      }
    ],
    "votacao": [...],
    "visual": [...],
    "email": [...],
    "seguranca": [...]
  },
  "total": 25
}
```

**Response (específica):**
```json
{
  "success": true,
  "data": {
    "chave": "votacao_ativa",
    "valor": true,
    "tipo": "booleano",
    "descricao": "Controla se a votação está aberta"
  }
}
```

### Salvar Configurações

**POST/PUT** `/api/configuracoes/salvar.php`

🔒 Requer autenticação

**Request Body (única):**
```json
{
  "chave": "votacao_ativa",
  "valor": true,
  "tipo": "booleano"
}
```

**Request Body (múltiplas):**
```json
{
  "configuracoes": [
    {
      "chave": "votacao_ativa",
      "valor": true
    },
    {
      "chave": "data_gala",
      "valor": "2025-12-31 20:00:00"
    }
  ]
}
```

**Response:**
```json
{
  "success": true,
  "message": "Configurações salvas com sucesso!",
  "atualizadas": ["votacao_ativa", "data_gala"],
  "total_atualizadas": 2
}
```

---

## 📈 Estatísticas

### Dashboard

**GET** `/api/stats/dashboard.php`

Retorna todas as estatísticas para o dashboard.

**Response:**
```json
{
  "success": true,
  "data": {
    "total_votos": 15430,
    "total_candidatos": 45,
    "total_categorias": 5,
    "votantes_unicos": 8920,
    "votos_hoje": 342,
    "crescimento_hoje": 12.5,
    "dias_ate_gala": 47,
    "votos_por_categoria": [
      {
        "categoria_id": 1,
        "categoria_nome": "Melhor Ator",
        "icone": "fa-user-tie",
        "cor": "#FFD700",
        "total_votos": 3200
      }
    ],
    "evolucao_7_dias": [
      {
        "data": "2025-11-08",
        "dia_semana": "Seg",
        "total_votos": 1800
      }
    ],
    "top_candidatos": [
      {
        "id": 1,
        "nome": "Maria Costa",
        "foto_url": "https://...",
        "categoria_id": 2,
        "categoria_nome": "Melhor Atriz",
        "total_votos": 2450
      }
    ],
    "atividade_recente": [
      {
        "id": 123,
        "admin_id": 1,
        "admin_nome": "Admin João",
        "acao": "criar",
        "tabela": "candidatos",
        "created_at": "2025-11-14 15:00:00",
        "tempo_relativo": "15 minutos atrás",
        "ip_address": "197.***.***.***"
      }
    ]
  },
  "timestamp": "2025-11-14 15:30:00"
}
```

---

## 🚨 Códigos de Status HTTP

| Código | Significado |
|--------|-------------|
| 200 | OK - Requisição bem-sucedida |
| 201 | Created - Recurso criado |
| 400 | Bad Request - Dados inválidos |
| 401 | Unauthorized - Não autenticado |
| 403 | Forbidden - Sem permissão |
| 404 | Not Found - Recurso não encontrado |
| 409 | Conflict - Conflito (ex: já votou) |
| 500 | Internal Server Error - Erro no servidor |

---

## 📝 Formato de Erros

Todas as respostas de erro seguem o formato:

```json
{
  "success": false,
  "message": "Descrição do erro"
}
```

---

## 🔒 Segurança

### Headers Recomendados

Sempre inclua estes headers nas requisições:

```
Content-Type: application/json
Authorization: Bearer {token}
X-Requested-With: XMLHttpRequest
```

### Rate Limiting

- Votação: Máximo 1 voto por dia por categoria por dispositivo
- Login: Máximo 5 tentativas por minuto por IP
- API Geral: Máximo 100 requisições por minuto por IP

### CORS

A API aceita requisições de qualquer origem (desenvolvimento). Em produção, configure origens específicas no `.htaccess`:

```apache
Header set Access-Control-Allow-Origin "https://seudominio.com"
```

---

## 💡 Exemplos de Uso

### JavaScript (Fetch)

```javascript
// Login
const login = async () => {
    const response = await fetch('/api/auth/login.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            email: 'admin@gala.com',
            password: 'senha'
        })
    });
    
    const data = await response.json();
    if (data.success) {
        localStorage.setItem('token', data.token);
    }
};

// Votar
const votar = async (candidatoId, categoriaId, dispositivoId) => {
    const response = await fetch('/api/votar.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            candidato_id: candidatoId,
            categoria_id: categoriaId,
            dispositivo_id: dispositivoId
        })
    });
    
    return await response.json();
};
```

### PHP (Guzzle)

```php
use GuzzleHttp\Client;

$client = new Client(['base_uri' => 'https://seusite.com']);

// Listar candidatos
$response = $client->get('/api/candidatos/listar.php', [
    'query' => [
        'categoria_id' => 1,
        'page' => 1
    ]
]);

$data = json_decode($response->getBody(), true);
```

### cURL

```bash
# Login
curl -X POST https://seusite.com/api/auth/login.php \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@gala.com","password":"senha"}'

# Listar categorias
curl https://seusite.com/api/categorias/listar.php

# Criar candidato (com token)
curl -X POST https://seusite.com/api/candidatos/criar.php \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SEU_TOKEN" \
  -d '{"nome":"João Silva","categoria_id":1,"descricao_curta":"Ator","biografia":"Bio..."}'
```

---

## 📞 Suporte

Para dúvidas sobre a API:
- **Email**: dev@gala2025.com
- **GitHub Issues**: [Link]
- **Documentação**: README.md

---

**Versão**: 1.0.0  
**Última Atualização**: 14/11/2025