#!/bin/bash

# Script de configuração inicial para Gala de Premiação 2025
# Execute com: bash setup.sh

echo "🏆 Bem-vindo ao Setup da Gala de Premiação 2025!"
echo "================================================"
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para verificar comandos
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Verificar PHP
echo -e "${YELLOW}Verificando requisitos...${NC}"
if ! command_exists php; then
    echo -e "${RED}✗ PHP não encontrado. Instale PHP 8.0 ou superior.${NC}"
    exit 1
fi

PHP_VERSION=$(php -r 'echo PHP_VERSION;')
echo -e "${GREEN}✓ PHP $PHP_VERSION encontrado${NC}"

# Verificar Composer
if ! command_exists composer; then
    echo -e "${RED}✗ Composer não encontrado.${NC}"
    echo "Instale o Composer: https://getcomposer.org/download/"
    exit 1
fi
echo -e "${GREEN}✓ Composer encontrado${NC}"

# Verificar Git
if ! command_exists git; then
    echo -e "${YELLOW}⚠ Git não encontrado (opcional)${NC}"
else
    echo -e "${GREEN}✓ Git encontrado${NC}"
fi

echo ""
echo -e "${YELLOW}Instalando dependências do PHP...${NC}"
composer install --no-dev --optimize-autoloader

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Erro ao instalar dependências${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Dependências instaladas com sucesso${NC}"

echo ""
echo -e "${YELLOW}Configurando ambiente...${NC}"

# Criar arquivo .env se não existir
if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${GREEN}✓ Arquivo .env criado${NC}"
    
    # Gerar chaves de segurança
    SESSION_SECRET=$(openssl rand -base64 32)
    JWT_SECRET=$(openssl rand -base64 32)
    
    # Atualizar .env com chaves geradas
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/SESSION_SECRET=.*/SESSION_SECRET=$SESSION_SECRET/" .env
        sed -i '' "s/JWT_SECRET=.*/JWT_SECRET=$JWT_SECRET/" .env
    else
        # Linux
        sed -i "s/SESSION_SECRET=.*/SESSION_SECRET=$SESSION_SECRET/" .env
        sed -i "s/JWT_SECRET=.*/JWT_SECRET=$JWT_SECRET/" .env
    fi
    
    echo -e "${GREEN}✓ Chaves de segurança geradas${NC}"
    echo ""
    echo -e "${YELLOW}⚠ IMPORTANTE: Configure as seguintes variáveis no arquivo .env:${NC}"
    echo "  - SUPABASE_URL"
    echo "  - SUPABASE_KEY"
    echo "  - SITE_URL"
    echo ""
else
    echo -e "${YELLOW}⚠ Arquivo .env já existe. Pulando...${NC}"
fi

# Criar diretórios necessários
echo ""
echo -e "${YELLOW}Criando diretórios...${NC}"

mkdir -p uploads/categorias
mkdir -p uploads/candidatos
mkdir -p uploads/organizacoes
mkdir -p logs

echo -e "${GREEN}✓ Diretórios criados${NC}"

# Configurar permissões
echo ""
echo -e "${YELLOW}Configurando permissões...${NC}"

chmod -R 755 .
chmod 600 .env
chmod -R 775 uploads
chmod -R 775 logs

echo -e "${GREEN}✓ Permissões configuradas${NC}"

# Verificar conexão com Supabase
echo ""
echo -e "${YELLOW}Deseja testar a conexão com o Supabase agora? (s/n)${NC}"
read -r TEST_DB

if [ "$TEST_DB" = "s" ] || [ "$TEST_DB" = "S" ]; then
    php -r "
    require 'vendor/autoload.php';
    use Dotenv\Dotenv;
    
    \$dotenv = Dotenv::createImmutable(__DIR__);
    \$dotenv->load();
    
    if (empty(\$_ENV['SUPABASE_URL']) || empty(\$_ENV['SUPABASE_KEY'])) {
        echo \"\\033[0;31m✗ Configure SUPABASE_URL e SUPABASE_KEY no arquivo .env\\033[0m\\n\";
        exit(1);
    }
    
    try {
        \$client = new GuzzleHttp\Client([
            'base_uri' => \$_ENV['SUPABASE_URL'],
            'headers' => [
                'apikey' => \$_ENV['SUPABASE_KEY'],
                'Authorization' => 'Bearer ' . \$_ENV['SUPABASE_KEY']
            ]
        ]);
        
        \$response = \$client->get('/rest/v1/');
        echo \"\\033[0;32m✓ Conexão com Supabase OK\\033[0m\\n\";
    } catch (Exception \$e) {
        echo \"\\033[0;31m✗ Erro ao conectar com Supabase: \" . \$e->getMessage() . \"\\033[0m\\n\";
    }
    "
fi

echo ""
echo -e "${GREEN}================================================${NC}"
echo -e "${GREEN}✓ Setup concluído com sucesso!${NC}"
echo -e "${GREEN}================================================${NC}"
echo ""
echo -e "${YELLOW}Próximos passos:${NC}"
echo "1. Configure as credenciais do Supabase no arquivo .env"
echo "2. Execute o script SQL (gala_db_structure.sql) no Supabase"
echo "3. Crie o primeiro administrador no banco de dados"
echo "4. Configure seu servidor web (Apache/Nginx)"
echo "5. Acesse o painel em: /admin/login.html"
echo ""
echo "📚 Para mais informações, consulte:"
echo "   - README.md"
echo "   - DEPLOY.md"
echo ""
echo -e "${GREEN}Boa sorte com sua Gala! 🎉${NC}"